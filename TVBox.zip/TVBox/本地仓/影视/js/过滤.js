function filterSearch(list, wd) {
    let clean = s => (s || '').replace(/[\s·\-：:、《》【】『』（）\(\)]/g, '');
    let key = clean(wd);
    let ban = /解说|花絮|剪辑|短视频|抢先|合集|剧场版|番外|影评|预告|cut|短剧/gi;
    return list.filter(i => {
        let title = clean(i.vod_name || i.name || '');
        let raw = i.vod_name || i.name || '';
        return title === key && !ban.test(raw);
    });
}
